import FootballGame from "./components/FootballGame";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-200 via-sky-100 to-emerald-50 px-4 py-8">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-6">
        <header className="text-center">
          <h1 className="flex items-center justify-center gap-2 text-4xl font-extrabold tracking-tight text-slate-800 sm:text-5xl">
            <span>⚽</span>
            <span>ফুটবল স্ট্রাইকার</span>
          </h1>
          <p className="mt-2 text-slate-600">গোলরক্ষককে হারিয়ে যত বেশি সম্ভব গোল করো — সময় ফুরানোর আগে!</p>
        </header>

        <FootballGame />

        <footer className="pb-4 text-center text-xs text-slate-400">
          তৈরি করা হয়েছে React, Canvas ও ভালোবাসা দিয়ে ⚽
        </footer>
      </div>
    </div>
  );
}
