import { useEffect, useRef, useState, useCallback } from "react";

const WIDTH = 900;
const HEIGHT = 560;
const MARGIN = 30;
const FIELD_LEFT = MARGIN;
const FIELD_RIGHT = WIDTH - MARGIN;
const FIELD_TOP = MARGIN;
const FIELD_BOTTOM = HEIGHT - MARGIN;
const GOAL_MOUTH_HEIGHT = 140;
const GOAL_TOP = HEIGHT / 2 - GOAL_MOUTH_HEIGHT / 2;
const GOAL_BOTTOM = HEIGHT / 2 + GOAL_MOUTH_HEIGHT / 2;
const GOAL_DEPTH = 26;

const PLAYER_RADIUS = 11;
const KEEPER_RADIUS = 13;
const BALL_RADIUS = 7;

const PLAYER_MAX_SPEED = 225;
const BALL_FRICTION_HALF_LIFE = 0.35;
const MIN_KICK = 260;
const MAX_KICK = 680;
const CHARGE_TIME = 0.85;
const MATCH_TIME = 150;
const PASS_SPEED = 400;

type Team = "blue" | "red";
type Role = "GK" | "DF" | "MF" | "FW";

interface Player {
  id: string;
  team: Team;
  role: Role;
  isGK: boolean;
  number: number;
  baseOwnFracX: number;
  baseFracY: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facingX: number;
  facingY: number;
  slideTimer: number;
  slideCooldown: number;
  stumble: number;
  holdUntil?: number;
  seed: number;
}

interface GameState {
  players: Player[];
  ball: { x: number; y: number; vx: number; vy: number };
  ownerId: string | null;
  lastKicker: { id: string; time: number } | null;
  lastTouchTeam: Team | null;
  charging: boolean;
  chargeStart: number;
  lastKickTime: number;
  scoreBlue: number;
  scoreRed: number;
  time: number;
  status: "idle" | "playing" | "over";
  flash: { text: string; time: number; color: string } | null;
  shake: number;
  activeId: string;
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}
function dist(ax: number, ay: number, bx: number, by: number) {
  return Math.hypot(ax - bx, ay - by);
}

const FORMATION: { role: Role; xFrac: number; yFrac: number }[] = [
  { role: "GK", xFrac: 0.04, yFrac: 0.5 },
  { role: "DF", xFrac: 0.18, yFrac: 0.12 },
  { role: "DF", xFrac: 0.16, yFrac: 0.37 },
  { role: "DF", xFrac: 0.16, yFrac: 0.63 },
  { role: "DF", xFrac: 0.18, yFrac: 0.88 },
  { role: "MF", xFrac: 0.42, yFrac: 0.18 },
  { role: "MF", xFrac: 0.4, yFrac: 0.4 },
  { role: "MF", xFrac: 0.4, yFrac: 0.6 },
  { role: "MF", xFrac: 0.42, yFrac: 0.82 },
  { role: "FW", xFrac: 0.68, yFrac: 0.38 },
  { role: "FW", xFrac: 0.68, yFrac: 0.62 },
];

function generateTeam(team: Team): Player[] {
  return FORMATION.map((f, i) => {
    const isGK = f.role === "GK";
    const absFrac = team === "blue" ? f.xFrac : 1 - f.xFrac;
    const x = FIELD_LEFT + absFrac * (FIELD_RIGHT - FIELD_LEFT);
    const y = FIELD_TOP + f.yFrac * (FIELD_BOTTOM - FIELD_TOP);
    return {
      id: `${team}-${i}`,
      team,
      role: f.role,
      isGK,
      number: i + 1,
      baseOwnFracX: f.xFrac,
      baseFracY: f.yFrac,
      x,
      y,
      vx: 0,
      vy: 0,
      facingX: team === "blue" ? 1 : -1,
      facingY: 0,
      slideTimer: 0,
      slideCooldown: 0,
      stumble: 0,
      seed: Math.random() * 100,
    };
  });
}

function createInitialState(): GameState {
  const players = [...generateTeam("blue"), ...generateTeam("red")];
  return {
    players,
    ball: { x: WIDTH / 2, y: HEIGHT / 2, vx: 0, vy: 0 },
    ownerId: null,
    lastKicker: null,
    lastTouchTeam: null,
    charging: false,
    chargeStart: 0,
    lastKickTime: -10,
    scoreBlue: 0,
    scoreRed: 0,
    time: MATCH_TIME,
    status: "idle",
    flash: null,
    shake: 0,
    activeId: players.find((p) => p.team === "blue" && !p.isGK)!.id,
  };
}

// ---- audio ----
let audioCtx: AudioContext | null = null;
function getAudioCtx() {
  if (!audioCtx) {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new Ctx();
  }
  return audioCtx;
}
function beep(freq: number, duration: number, type: OscillatorType = "sine", vol = 0.15, delay = 0) {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = vol;
    osc.connect(gain);
    gain.connect(ctx.destination);
    const startTime = ctx.currentTime + delay;
    gain.gain.setValueAtTime(vol, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    osc.start(startTime);
    osc.stop(startTime + duration);
  } catch {
    /* ignore */
  }
}
const playKickSound = () => beep(220, 0.1, "triangle", 0.16);
const playPassSound = () => beep(340, 0.07, "sine", 0.1);
const playSlideSound = () => beep(120, 0.15, "sawtooth", 0.12);
const playTackleWin = () => beep(400, 0.1, "square", 0.14);
const playGoalSound = () => {
  beep(523, 0.15, "sine", 0.2);
  beep(659, 0.15, "sine", 0.2, 0.12);
  beep(784, 0.25, "sine", 0.22, 0.24);
};
const playConcedeSound = () => {
  beep(300, 0.2, "sawtooth", 0.15);
  beep(200, 0.3, "sawtooth", 0.15, 0.15);
};
const playWhistle = () => beep(1200, 0.3, "square", 0.12);

// ---- generic AI/physics helpers ----
function accelerateTowards(p: Player, targetVx: number, targetVy: number, dt: number, rate: number) {
  const accel = 1 - Math.exp(-rate * dt);
  p.vx += (targetVx - p.vx) * accel;
  p.vy += (targetVy - p.vy) * accel;
}
function integratePlayerPosition(p: Player, dt: number) {
  p.x += p.vx * dt;
  p.y += p.vy * dt;
  const r = p.isGK ? KEEPER_RADIUS : PLAYER_RADIUS;
  p.x = clamp(p.x, FIELD_LEFT + r, FIELD_RIGHT - r);
  p.y = clamp(p.y, FIELD_TOP + r, FIELD_BOTTOM - r);
}
function moveToward(p: Player, tx: number, ty: number, speed: number, dt: number, rate = 8) {
  const dx = tx - p.x;
  const dy = ty - p.y;
  const len = Math.hypot(dx, dy) || 1;
  const actualSpeed = p.stumble > 0 ? speed * 0.5 : speed;
  const vx = len > 2 ? (dx / len) * actualSpeed : 0;
  const vy = len > 2 ? (dy / len) * actualSpeed : 0;
  accelerateTowards(p, vx, vy, dt, rate);
  if (len > 2) {
    p.facingX = dx / len;
    p.facingY = dy / len;
  }
}
function attachBallToFeet(ball: GameState["ball"], p: Player, dt: number) {
  const tx = p.x + p.facingX * (PLAYER_RADIUS + BALL_RADIUS + 4);
  const ty = p.y + p.facingY * (PLAYER_RADIUS + BALL_RADIUS + 4);
  ball.x += (tx - ball.x) * clamp(10 * dt, 0, 1);
  ball.y += (ty - ball.y) * clamp(10 * dt, 0, 1);
  ball.vx = p.vx;
  ball.vy = p.vy;
}
function computeHome(p: Player, ball: { x: number; y: number }) {
  const fieldWidth = FIELD_RIGHT - FIELD_LEFT;
  const fieldHeight = FIELD_BOTTOM - FIELD_TOP;
  const ballFracX = clamp((ball.x - FIELD_LEFT) / fieldWidth, 0, 1);
  const attackFrac = p.team === "blue" ? ballFracX : 1 - ballFracX;
  const shiftFactor = p.role === "DF" ? 0.07 : p.role === "MF" ? 0.13 : 0.19;
  const shift = (attackFrac - 0.5) * shiftFactor;
  const ownFrac = clamp(p.baseOwnFracX + shift, 0.05, 0.95);
  const absFrac = p.team === "blue" ? ownFrac : 1 - ownFrac;
  const homeX = FIELD_LEFT + absFrac * fieldWidth;
  let homeY = FIELD_TOP + p.baseFracY * fieldHeight;
  homeY += clamp((ball.y - homeY) * 0.08, -35, 35);
  homeY = clamp(homeY, FIELD_TOP + 20, FIELD_BOTTOM - 20);
  return { x: homeX, y: homeY };
}
function nearestPlayerId(list: Player[], x: number, y: number): string | null {
  if (list.length === 0) return null;
  let best = list[0];
  let bd = dist(best.x, best.y, x, y);
  for (const p of list) {
    const d = dist(p.x, p.y, x, y);
    if (d < bd) {
      bd = d;
      best = p;
    }
  }
  return best.id;
}
function choosePassTarget(player: Player, teammates: Player[]): Player | null {
  const candidates = teammates.filter((p) => p.id !== player.id && !p.isGK);
  if (candidates.length === 0) return null;
  let best: Player | null = null;
  let bestScore = -Infinity;
  for (const c of candidates) {
    const d = dist(player.x, player.y, c.x, c.y);
    if (d < 25 || d > 480) continue;
    const forwardDelta = player.team === "blue" ? c.x - player.x : player.x - c.x;
    const score = forwardDelta - d * 0.4;
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  }
  if (!best) {
    best = candidates.reduce((a, b) =>
      dist(player.x, player.y, a.x, a.y) < dist(player.x, player.y, b.x, b.y) ? a : b
    );
  }
  return best;
}

export default function FootballGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameState>(createInitialState());
  const keysRef = useRef<Set<string>>(new Set());
  const pressedOnceRef = useRef<Set<string>>(new Set());
  const rafRef = useRef<number | null>(null);
  const lastTsRef = useRef<number | null>(null);
  const uiAccumRef = useRef(0);

  const [status, setStatus] = useState<"idle" | "playing" | "over">("idle");
  const [scoreBlue, setScoreBlue] = useState(0);
  const [scoreRed, setScoreRed] = useState(0);
  const [timeLeft, setTimeLeft] = useState(MATCH_TIME);
  const [resultMsg, setResultMsg] = useState<string>("");
  const [wins, setWins] = useState<number>(() => {
    const saved = localStorage.getItem("football-wins");
    return saved ? parseInt(saved, 10) : 0;
  });

  // ---- input handling ----
  useEffect(() => {
    const trackedKeys = [
      "ArrowUp",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "w",
      "a",
      "s",
      "d",
      "W",
      "A",
      "S",
      "D",
      " ",
      "e",
      "E",
      "f",
      "F",
      "r",
      "R",
    ];
    const onKeyDown = (e: KeyboardEvent) => {
      if (trackedKeys.includes(e.key)) e.preventDefault();
      const norm = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      keysRef.current.add(norm);
      if (!e.repeat) {
        if (norm === "e") pressedOnceRef.current.add("pass");
        if (norm === "f") pressedOnceRef.current.add("slide");
      }
      if ((norm === "r") && gameRef.current.status === "over") {
        restartGame();
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const norm = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      keysRef.current.delete(norm);
    };
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resetKickoff = useCallback((g: GameState) => {
    for (const p of g.players) {
      if (p.isGK) {
        p.x = p.team === "blue" ? FIELD_LEFT + 16 : FIELD_RIGHT - 16;
        p.y = HEIGHT / 2;
      } else {
        const home = computeHome(p, { x: WIDTH / 2, y: HEIGHT / 2 });
        p.x = home.x;
        p.y = home.y;
      }
      p.vx = 0;
      p.vy = 0;
      p.slideTimer = 0;
      p.slideCooldown = 0;
      p.stumble = 0;
      p.holdUntil = undefined;
      p.facingX = p.team === "blue" ? 1 : -1;
      p.facingY = 0;
    }
    g.ball.x = WIDTH / 2;
    g.ball.y = HEIGHT / 2;
    g.ball.vx = 0;
    g.ball.vy = 0;
    g.ownerId = null;
    g.lastKicker = null;
    g.charging = false;
  }, []);

  const startGame = useCallback(() => {
    try {
      getAudioCtx().resume();
    } catch {
      /* ignore */
    }
    playWhistle();
    const g = createInitialState();
    resetKickoff(g);
    g.status = "playing";
    gameRef.current = g;
    setScoreBlue(0);
    setScoreRed(0);
    setTimeLeft(MATCH_TIME);
    setResultMsg("");
    setStatus("playing");
  }, [resetKickoff]);

  const restartGame = useCallback(() => {
    startGame();
  }, [startGame]);

  // ---- main loop ----
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = WIDTH * dpr;
    canvas.height = HEIGHT * dpr;
    ctx.scale(dpr, dpr);

    function getInputVector() {
      const keys = keysRef.current;
      let x = 0;
      let y = 0;
      if (keys.has("ArrowLeft") || keys.has("a")) x -= 1;
      if (keys.has("ArrowRight") || keys.has("d")) x += 1;
      if (keys.has("ArrowUp") || keys.has("w")) y -= 1;
      if (keys.has("ArrowDown") || keys.has("s")) y += 1;
      const len = Math.hypot(x, y);
      if (len > 0) {
        x /= len;
        y /= len;
      }
      return { x, y };
    }

    function consumeOnce(name: string) {
      if (pressedOnceRef.current.has(name)) {
        pressedOnceRef.current.delete(name);
        return true;
      }
      return false;
    }

    function executePass(g: GameState, passer: Player, now: number) {
      const teammates = g.players.filter((p) => p.team === passer.team);
      const target = choosePassTarget(passer, teammates);
      if (!target) return;
      const leadX = target.x + target.vx * 0.3;
      const leadY = target.y + target.vy * 0.3;
      const dx = leadX - passer.x;
      const dy = leadY - passer.y;
      const len = Math.hypot(dx, dy) || 1;
      g.ball.vx = (dx / len) * PASS_SPEED;
      g.ball.vy = (dy / len) * PASS_SPEED;
      g.ownerId = null;
      g.lastKicker = { id: passer.id, time: now };
      g.lastTouchTeam = passer.team;
      g.lastKickTime = now;
      playPassSound();
    }

    function redDribblerAI(g: GameState, player: Player, now: number, dt: number) {
      const attackGoalX = player.team === "blue" ? FIELD_RIGHT : FIELD_LEFT;
      const weaveY = HEIGHT / 2 + Math.sin(now * 0.7 + player.seed) * 30;
      const opponents = g.players.filter((p) => p.team !== player.team && !p.isGK);
      let nearestDef: Player | null = null;
      let nd = Infinity;
      for (const d of opponents) {
        const dd = dist(d.x, d.y, player.x, player.y);
        if (dd < nd) {
          nd = dd;
          nearestDef = d;
        }
      }
      const pressured = nd < 60;
      const inShootRange = Math.abs(player.x - attackGoalX) < 230 && Math.abs(player.y - HEIGHT / 2) < 170;

      if (inShootRange && Math.random() < dt * 0.6) {
        const tx = attackGoalX;
        const ty = HEIGHT / 2 + (Math.random() - 0.5) * GOAL_MOUTH_HEIGHT * 0.7;
        const dx = tx - player.x;
        const dy = ty - player.y;
        const len = Math.hypot(dx, dy) || 1;
        const power = MIN_KICK + Math.random() * (MAX_KICK - MIN_KICK);
        g.ball.vx = (dx / len) * power;
        g.ball.vy = (dy / len) * power;
        g.ownerId = null;
        g.lastKicker = { id: player.id, time: now };
        g.lastTouchTeam = player.team;
        g.lastKickTime = now;
        playKickSound();
        return;
      }
      if (pressured && Math.random() < dt * 2.0) {
        executePass(g, player, now);
        return;
      }
      if (!pressured && Math.random() < dt * 0.2) {
        executePass(g, player, now);
        return;
      }

      let dirX = attackGoalX - player.x;
      let dirY = weaveY - player.y;
      const len1 = Math.hypot(dirX, dirY) || 1;
      dirX /= len1;
      dirY /= len1;
      if (nearestDef && nd < 70) {
        const rx = player.x - nearestDef.x;
        const ry = player.y - nearestDef.y;
        const rl = Math.hypot(rx, ry) || 1;
        dirX += (rx / rl) * 0.6;
        dirY += (ry / rl) * 0.6;
        const nl = Math.hypot(dirX, dirY) || 1;
        dirX /= nl;
        dirY /= nl;
      }
      const speed = PLAYER_MAX_SPEED * (player.stumble > 0 ? 0.4 : 0.82);
      accelerateTowards(player, dirX * speed, dirY * speed, dt, 8);
      player.facingX = dirX;
      player.facingY = dirY;
      integratePlayerPosition(player, dt);
      attachBallToFeet(g.ball, player, dt);
    }

    function gkPositioning(p: Player, g: GameState, dt: number) {
      const ownGoalX = p.team === "blue" ? FIELD_LEFT + 16 : FIELD_RIGHT - 16;
      const targetY = clamp(g.ball.y, GOAL_TOP + KEEPER_RADIUS + 2, GOAL_BOTTOM - KEEPER_RADIUS - 2);
      moveToward(p, ownGoalX, targetY, 190, dt, 6);
      integratePlayerPosition(p, dt);
    }

    function resolveCollisions(players: Player[]) {
      for (let i = 0; i < players.length; i++) {
        for (let j = i + 1; j < players.length; j++) {
          const a = players[i];
          const b = players[j];
          const ra = a.isGK ? KEEPER_RADIUS : PLAYER_RADIUS;
          const rb = b.isGK ? KEEPER_RADIUS : PLAYER_RADIUS;
          const minDist = ra + rb;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const d = Math.hypot(dx, dy) || 0.001;
          if (d < minDist) {
            const overlap = (minDist - d) / 2;
            const nx = dx / d;
            const ny = dy / d;
            a.x -= nx * overlap;
            a.y -= ny * overlap;
            b.x += nx * overlap;
            b.y += ny * overlap;
          }
        }
      }
      for (const p of players) {
        const r = p.isGK ? KEEPER_RADIUS : PLAYER_RADIUS;
        p.x = clamp(p.x, FIELD_LEFT + r, FIELD_RIGHT - r);
        p.y = clamp(p.y, FIELD_TOP + r, FIELD_BOTTOM - r);
      }
    }

    function onGoalScored(g: GameState, scoringTeam: Team, now: number) {
      if (scoringTeam === "blue") {
        g.scoreBlue += 1;
        g.flash = { text: "গোল!! ⚽", time: now, color: "#facc15" };
        playGoalSound();
      } else {
        g.scoreRed += 1;
        g.flash = { text: "বিপক্ষ গোল!", time: now, color: "#f87171" };
        playConcedeSound();
      }
      g.shake = 16;
      setScoreBlue(g.scoreBlue);
      setScoreRed(g.scoreRed);
      resetKickoff(g);
    }

    function checkGKCapture(g: GameState, now: number) {
      for (const gk of g.players) {
        if (!gk.isGK) continue;
        const d = dist(g.ball.x, g.ball.y, gk.x, gk.y);
        const immune = g.lastKicker && g.lastKicker.id === gk.id && now - g.lastKicker.time < 0.4;
        if (d < 22 && !immune) {
          g.ownerId = gk.id;
          return true;
        }
      }
      return false;
    }

    function checkGoal(g: GameState, now: number) {
      const inMouth = g.ball.y > GOAL_TOP && g.ball.y < GOAL_BOTTOM;
      if (inMouth && g.ball.x + BALL_RADIUS > FIELD_RIGHT) {
        onGoalScored(g, "blue", now);
        return true;
      }
      if (inMouth && g.ball.x - BALL_RADIUS < FIELD_LEFT) {
        onGoalScored(g, "red", now);
        return true;
      }
      return false;
    }

    function checkGeneralCapture(g: GameState, now: number) {
      let bestP: Player | null = null;
      let bestD = Infinity;
      for (const p of g.players) {
        if (p.isGK) continue;
        const immune = g.lastKicker && g.lastKicker.id === p.id && now - g.lastKicker.time < 0.4;
        if (immune) continue;
        const d = dist(g.ball.x, g.ball.y, p.x, p.y);
        if (d < 16 && d < bestD) {
          bestD = d;
          bestP = p;
        }
      }
      if (bestP) g.ownerId = bestP.id;
    }

    function endMatch(g: GameState) {
      g.status = "over";
      setStatus("over");
      let msg = "";
      if (g.scoreBlue > g.scoreRed) {
        msg = "🏆 তুমি জিতেছো!";
        const next = wins + 1;
        setWins(next);
        localStorage.setItem("football-wins", String(next));
      } else if (g.scoreBlue < g.scoreRed) {
        msg = "😔 তুমি হেরে গেছো";
      } else {
        msg = "🤝 ম্যাচ ড্র হয়েছে";
      }
      setResultMsg(msg);
    }

    function update(dt: number, now: number) {
      const g = gameRef.current;
      if (g.status !== "playing") return;

      const wantPass = consumeOnce("pass");
      const wantSlide = consumeOnce("slide");

      const owner = g.ownerId ? g.players.find((p) => p.id === g.ownerId) || null : null;
      let activeId: string;
      if (owner && owner.team === "blue" && !owner.isGK) {
        activeId = owner.id;
      } else {
        const blueField = g.players.filter((p) => p.team === "blue" && !p.isGK);
        activeId = blueField.reduce((best, p) =>
          dist(p.x, p.y, g.ball.x, g.ball.y) < dist(best.x, best.y, g.ball.x, g.ball.y) ? p : best
        ).id;
      }
      g.activeId = activeId;
      const activePlayer = g.players.find((p) => p.id === activeId)!;

      // active player movement
      if (activePlayer.slideTimer <= 0) {
        const input = getInputVector();
        const speed = activePlayer.stumble > 0 ? PLAYER_MAX_SPEED * 0.45 : PLAYER_MAX_SPEED;
        accelerateTowards(activePlayer, input.x * speed, input.y * speed, dt, 12);
        if (input.x !== 0 || input.y !== 0) {
          activePlayer.facingX = input.x;
          activePlayer.facingY = input.y;
        }
      }
      integratePlayerPosition(activePlayer, dt);

      // timers decay
      for (const p of g.players) {
        if (p.slideTimer > 0) {
          p.slideTimer -= dt;
          if (p.slideTimer <= 0) p.slideCooldown = 0.7;
        } else if (p.slideCooldown > 0) {
          p.slideCooldown -= dt;
        }
        if (p.stumble > 0) p.stumble -= dt;
      }

      // slide tackle trigger
      if (
        wantSlide &&
        activePlayer.slideTimer <= 0 &&
        activePlayer.slideCooldown <= 0 &&
        !(owner && owner.id === activePlayer.id)
      ) {
        const dx = g.ball.x - activePlayer.x;
        const dy = g.ball.y - activePlayer.y;
        const len = Math.hypot(dx, dy) || 1;
        const burst = 430;
        activePlayer.vx = (dx / len) * burst;
        activePlayer.vy = (dy / len) * burst;
        activePlayer.slideTimer = 0.28;
        playSlideSound();
      }

      // pass trigger
      if (wantPass && owner && owner.id === activePlayer.id) {
        executePass(g, activePlayer, now);
      }

      // shoot charge
      const spaceDown = keysRef.current.has(" ");
      const isOwnerActive = !!owner && owner.id === activePlayer.id;
      if (spaceDown && !g.charging && isOwnerActive && activePlayer.slideTimer <= 0 && now - g.lastKickTime > 0.15) {
        g.charging = true;
        g.chargeStart = now;
      }
      if (g.charging) {
        if (!isOwnerActive) {
          g.charging = false;
        } else {
          const elapsed = now - g.chargeStart;
          const c = clamp(elapsed / CHARGE_TIME, 0, 1);
          if (!spaceDown) {
            const power = MIN_KICK + c * (MAX_KICK - MIN_KICK);
            g.ball.vx = activePlayer.facingX * power;
            g.ball.vy = activePlayer.facingY * power;
            g.ownerId = null;
            g.lastKicker = { id: activePlayer.id, time: now };
            g.lastTouchTeam = "blue";
            g.lastKickTime = now;
            playKickSound();
            g.charging = false;
          }
        }
      }

      // ball / owner logic
      if (g.ownerId) {
        const ownerP = g.players.find((p) => p.id === g.ownerId)!;
        if (ownerP.isGK) {
          if (ownerP.holdUntil === undefined) ownerP.holdUntil = now + 0.5 + Math.random() * 0.3;
          g.ball.x = ownerP.x;
          g.ball.y = ownerP.y;
          g.ball.vx = 0;
          g.ball.vy = 0;
          if (now >= ownerP.holdUntil) {
            const dir = ownerP.team === "blue" ? 1 : -1;
            const ySpread = (Math.random() - 0.5) * 0.6;
            const len = Math.hypot(1, ySpread);
            g.ball.vx = (dir / len) * (380 + Math.random() * 150);
            g.ball.vy = (ySpread / len) * (380 + Math.random() * 150);
            g.ownerId = null;
            ownerP.holdUntil = undefined;
            g.lastKicker = { id: ownerP.id, time: now };
            g.lastTouchTeam = ownerP.team;
            g.lastKickTime = now;
            playKickSound();
          }
        } else if (ownerP.team === "blue") {
          if (!g.charging) attachBallToFeet(g.ball, ownerP, dt);
        } else {
          redDribblerAI(g, ownerP, now, dt);
        }
      } else {
        const decay = Math.pow(0.5, dt / BALL_FRICTION_HALF_LIFE);
        g.ball.vx *= decay;
        g.ball.vy *= decay;
        g.ball.x += g.ball.vx * dt;
        g.ball.y += g.ball.vy * dt;

        if (g.ball.y - BALL_RADIUS < FIELD_TOP) {
          g.ball.y = FIELD_TOP + BALL_RADIUS;
          g.ball.vy *= -0.6;
        }
        if (g.ball.y + BALL_RADIUS > FIELD_BOTTOM) {
          g.ball.y = FIELD_BOTTOM - BALL_RADIUS;
          g.ball.vy *= -0.6;
        }
        const inMouth = g.ball.y > GOAL_TOP && g.ball.y < GOAL_BOTTOM;
        if (!inMouth) {
          if (g.ball.x - BALL_RADIUS < FIELD_LEFT) {
            g.ball.x = FIELD_LEFT + BALL_RADIUS;
            g.ball.vx *= -0.6;
          }
          if (g.ball.x + BALL_RADIUS > FIELD_RIGHT) {
            g.ball.x = FIELD_RIGHT - BALL_RADIUS;
            g.ball.vx *= -0.6;
          }
        }

        const gkCaptured = checkGKCapture(g, now);
        if (!gkCaptured) {
          const scored = checkGoal(g, now);
          if (!scored && !g.ownerId) checkGeneralCapture(g, now);
        }
      }

      // passive contest + slide tackle resolution
      if (g.ownerId) {
        const ownerP = g.players.find((p) => p.id === g.ownerId)!;
        if (!ownerP.isGK) {
          for (const opp of g.players) {
            if (opp.team === ownerP.team) continue;
            const d = dist(opp.x, opp.y, ownerP.x, ownerP.y);
            if (d < 22 && Math.random() < dt * 0.15) {
              g.ownerId = null;
              const ang = Math.random() * Math.PI * 2;
              g.ball.vx = Math.cos(ang) * 90;
              g.ball.vy = Math.sin(ang) * 90;
              ownerP.stumble = 0.35;
              g.lastKicker = { id: opp.id, time: now };
              g.lastTouchTeam = opp.team;
              break;
            }
          }
        }
        if (
          g.ownerId &&
          activePlayer.slideTimer > 0 &&
          g.players.find((p) => p.id === g.ownerId)?.team === "red"
        ) {
          const redOwner = g.players.find((p) => p.id === g.ownerId)!;
          if (dist(activePlayer.x, activePlayer.y, redOwner.x, redOwner.y) < 24 && Math.random() < 0.85) {
            g.ownerId = activePlayer.id;
            redOwner.stumble = 0.5;
            g.lastTouchTeam = "blue";
            playTackleWin();
          }
        }
      }

      // AI movement for everyone else
      let nearestBlueChaser: string | null = null;
      let nearestRedChaser: string | null = null;
      if (!g.ownerId) {
        nearestBlueChaser = nearestPlayerId(
          g.players.filter((p) => p.team === "blue" && !p.isGK),
          g.ball.x,
          g.ball.y
        );
        nearestRedChaser = nearestPlayerId(
          g.players.filter((p) => p.team === "red" && !p.isGK),
          g.ball.x,
          g.ball.y
        );
      }
      for (const p of g.players) {
        if (p.id === activePlayer.id) continue;
        if (g.ownerId === p.id) continue;
        if (p.isGK) {
          gkPositioning(p, g, dt);
          continue;
        }
        const home = computeHome(p, g.ball);
        let targetX = home.x;
        let targetY = home.y;
        let speed = PLAYER_MAX_SPEED * 0.72;
        if (
          !g.ownerId &&
          ((p.team === "blue" && p.id === nearestBlueChaser) || (p.team === "red" && p.id === nearestRedChaser))
        ) {
          const d = dist(p.x, p.y, g.ball.x, g.ball.y);
          if (d < 260) {
            targetX = g.ball.x;
            targetY = g.ball.y;
            speed = PLAYER_MAX_SPEED * 0.95;
          }
        }
        moveToward(p, targetX, targetY, speed, dt, 7);
        integratePlayerPosition(p, dt);
      }

      resolveCollisions(g.players);

      if (g.shake > 0) g.shake = Math.max(0, g.shake - dt * 40);

      g.time -= dt;
      if (g.time <= 0) {
        g.time = 0;
        endMatch(g);
      }

      uiAccumRef.current += dt;
      if (uiAccumRef.current > 0.15) {
        uiAccumRef.current = 0;
        setTimeLeft(Math.ceil(g.time));
      }
    }

    function drawField() {
      if (!ctx) return;
      ctx.fillStyle = "#1b7a3d";
      ctx.fillRect(0, 0, WIDTH, HEIGHT);
      const stripeCount = 10;
      const stripeW = WIDTH / stripeCount;
      for (let i = 0; i < stripeCount; i++) {
        ctx.fillStyle = i % 2 === 0 ? "rgba(255,255,255,0.045)" : "rgba(0,0,0,0.035)";
        ctx.fillRect(i * stripeW, 0, stripeW, HEIGHT);
      }
      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.lineWidth = 3;
      ctx.strokeRect(FIELD_LEFT, FIELD_TOP, FIELD_RIGHT - FIELD_LEFT, FIELD_BOTTOM - FIELD_TOP);
      ctx.beginPath();
      ctx.moveTo(WIDTH / 2, FIELD_TOP);
      ctx.lineTo(WIDTH / 2, FIELD_BOTTOM);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(WIDTH / 2, HEIGHT / 2, 55, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(WIDTH / 2, HEIGHT / 2, 3, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.fill();

      // penalty boxes both ends
      ctx.strokeRect(FIELD_LEFT, HEIGHT / 2 - 100, 110, 200);
      ctx.strokeRect(FIELD_LEFT, HEIGHT / 2 - 55, 46, 110);
      ctx.strokeRect(FIELD_RIGHT - 110, HEIGHT / 2 - 100, 110, 200);
      ctx.strokeRect(FIELD_RIGHT - 46, HEIGHT / 2 - 55, 46, 110);

      // goal nets
      for (const side of ["left", "right"] as const) {
        const x0 = side === "left" ? FIELD_LEFT - GOAL_DEPTH : FIELD_RIGHT;
        ctx.fillStyle = "rgba(255,255,255,0.15)";
        ctx.fillRect(x0, GOAL_TOP, GOAL_DEPTH, GOAL_MOUTH_HEIGHT);
        ctx.strokeStyle = "rgba(255,255,255,0.6)";
        ctx.lineWidth = 1;
        for (let i = 0; i <= 6; i++) {
          const gx = x0 + (i * GOAL_DEPTH) / 6;
          ctx.beginPath();
          ctx.moveTo(gx, GOAL_TOP);
          ctx.lineTo(gx, GOAL_BOTTOM);
          ctx.stroke();
        }
        for (let i = 0; i <= 5; i++) {
          const gy = GOAL_TOP + (i * GOAL_MOUTH_HEIGHT) / 5;
          ctx.beginPath();
          ctx.moveTo(x0, gy);
          ctx.lineTo(x0 + GOAL_DEPTH, gy);
          ctx.stroke();
        }
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 4;
        const lineX = side === "left" ? FIELD_LEFT : FIELD_RIGHT;
        ctx.beginPath();
        ctx.moveTo(lineX, GOAL_TOP);
        ctx.lineTo(lineX, GOAL_BOTTOM);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x0 + (side === "left" ? 0 : GOAL_DEPTH), GOAL_TOP);
        ctx.lineTo(x0 + (side === "left" ? 0 : GOAL_DEPTH), GOAL_BOTTOM);
        ctx.stroke();
      }
    }

    function drawPlayer(p: Player, isActive: boolean) {
      if (!ctx) return;
      ctx.save();
      ctx.translate(p.x, p.y);
      const r = p.isGK ? KEEPER_RADIUS : PLAYER_RADIUS;
      // shadow
      ctx.beginPath();
      ctx.ellipse(0, r + 3, r * 0.75, 4, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fill();
      if (isActive) {
        ctx.beginPath();
        ctx.arc(0, 0, r + 5, 0, Math.PI * 2);
        ctx.strokeStyle = "#facc15";
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      let fill = "#2563eb";
      let stroke = "#1e3a8a";
      if (p.team === "blue" && p.isGK) {
        fill = "#38bdf8";
        stroke = "#0369a1";
      } else if (p.team === "red" && !p.isGK) {
        fill = "#dc2626";
        stroke = "#7f1d1d";
      } else if (p.team === "red" && p.isGK) {
        fill = "#f97316";
        stroke = "#7c2d12";
      }
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold ${r}px sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(p.number), 0, 1);
      if (isActive) {
        ctx.beginPath();
        ctx.moveTo(p.facingX * r * 0.3, p.facingY * r * 0.3);
        ctx.lineTo(p.facingX * r * 1.6, p.facingY * r * 1.6);
        ctx.strokeStyle = "#fef08a";
        ctx.lineWidth = 3;
        ctx.stroke();
      }
      ctx.restore();
    }

    function drawBall(g: GameState) {
      if (!ctx) return;
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(g.ball.x, g.ball.y + BALL_RADIUS + 2, BALL_RADIUS * 0.8, 3, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fill();
      ctx.beginPath();
      ctx.arc(g.ball.x, g.ball.y, BALL_RADIUS, 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
      ctx.strokeStyle = "#111827";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(g.ball.x, g.ball.y, 2.6, 0, Math.PI * 2);
      ctx.fillStyle = "#111827";
      ctx.fill();
      ctx.restore();
    }

    function drawChargeBar(g: GameState, activePlayer: Player) {
      if (!ctx || !g.charging) return;
      const elapsed = performance.now() / 1000 - g.chargeStart;
      const c = clamp(elapsed / CHARGE_TIME, 0, 1);
      const w = 46;
      const x = activePlayer.x - w / 2;
      const y = activePlayer.y - PLAYER_RADIUS - 16;
      ctx.fillStyle = "rgba(0,0,0,0.4)";
      ctx.fillRect(x, y, w, 6);
      ctx.fillStyle = c > 0.75 ? "#ef4444" : c > 0.4 ? "#facc15" : "#4ade80";
      ctx.fillRect(x, y, w * c, 6);
      ctx.strokeStyle = "white";
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, w, 6);
    }

    function drawFlash(g: GameState, now: number) {
      if (!ctx || !g.flash) return;
      const elapsed = now - g.flash.time;
      if (elapsed > 1.1) {
        g.flash = null;
        return;
      }
      const alpha = 1 - elapsed / 1.1;
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = "bold 50px sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = g.flash.color;
      ctx.strokeStyle = "rgba(0,0,0,0.5)";
      ctx.lineWidth = 4;
      const y = HEIGHT / 2 - 40 - elapsed * 20;
      ctx.strokeText(g.flash.text, WIDTH / 2, y);
      ctx.fillText(g.flash.text, WIDTH / 2, y);
      ctx.restore();
    }

    function render(now: number) {
      if (!ctx) return;
      const g = gameRef.current;
      ctx.save();
      if (g.shake > 0) {
        ctx.translate((Math.random() - 0.5) * g.shake, (Math.random() - 0.5) * g.shake);
      }
      drawField();
      const activePlayer = g.players.find((p) => p.id === g.activeId);
      for (const p of g.players) {
        drawPlayer(p, p.id === g.activeId);
      }
      drawBall(g);
      if (activePlayer) drawChargeBar(g, activePlayer);
      drawFlash(g, now);
      ctx.restore();
    }

    function loop(ts: number) {
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = Math.min((ts - lastTsRef.current) / 1000, 0.05);
      lastTsRef.current = ts;
      update(dt, ts / 1000);
      render(ts / 1000);
      rafRef.current = requestAnimationFrame(loop);
    }

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      lastTsRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetKickoff, wins]);

  const setKey = (key: string, down: boolean) => {
    if (down) keysRef.current.add(key);
    else keysRef.current.delete(key);
  };
  const triggerOnce = (name: string) => pressedOnceRef.current.add(name);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="flex w-full flex-col items-center gap-4">
      {/* scoreboard */}
      <div className="flex w-full max-w-[900px] items-center justify-between rounded-xl bg-slate-900/90 px-5 py-3 text-white shadow-lg">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-blue-500" />
          <span className="text-sm uppercase tracking-wider text-slate-400">তুমি</span>
          <span className="text-2xl font-bold text-blue-400">{scoreBlue}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm uppercase tracking-wider text-slate-400">সময়</span>
          <span className="font-mono text-2xl font-bold tabular-nums">
            {minutes}:{seconds.toString().padStart(2, "0")}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold text-red-400">{scoreRed}</span>
          <span className="text-sm uppercase tracking-wider text-slate-400">প্রতিপক্ষ</span>
          <span className="h-3 w-3 rounded-full bg-red-500" />
        </div>
      </div>

      <div className="relative w-full max-w-[900px] overflow-hidden rounded-2xl border-4 border-emerald-900 shadow-2xl">
        <canvas
          ref={canvasRef}
          style={{ width: "100%", height: "auto", display: "block", aspectRatio: `${WIDTH} / ${HEIGHT}` }}
        />

        {status === "idle" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/75 text-center text-white backdrop-blur-sm">
            <h2 className="text-3xl font-extrabold drop-shadow sm:text-4xl">⚽ ফুটবল ম্যাচ: ১১ বনাম ১১</h2>
            <p className="max-w-lg px-6 text-slate-200">
              তোমার নীল দল বনাম লাল প্রতিপক্ষ দল — প্রতিটি দলে ১১ জন খেলোয়াড় ও গোলরক্ষক। বেশি গোল করে ম্যাচ জিতো!
            </p>
            <div className="grid grid-cols-1 gap-1 text-sm text-slate-300">
              <p>
                <span className="font-semibold text-white">WASD / তীর কী</span> — দৌড়ানো
              </p>
              <p>
                <span className="font-semibold text-white">স্পেস (চেপে ধরুন)</span> — শট চার্জ করে ছেড়ে দিন
              </p>
              <p>
                <span className="font-semibold text-white">E</span> — সতীর্থকে পাস দিন
              </p>
              <p>
                <span className="font-semibold text-white">F</span> — প্রতিপক্ষকে স্লাইড ট্যাকল করুন
              </p>
            </div>
            <button
              onClick={startGame}
              className="mt-2 rounded-full bg-emerald-500 px-8 py-3 text-lg font-bold text-white shadow-lg transition hover:scale-105 hover:bg-emerald-400 active:scale-95"
            >
              ম্যাচ শুরু করুন ▶
            </button>
            {wins > 0 && <p className="text-xs text-emerald-300">মোট জয়: {wins} 🏆</p>}
          </div>
        )}

        {status === "over" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 text-center text-white backdrop-blur-sm">
            <h2 className="text-3xl font-extrabold">⏱ ম্যাচ শেষ!</h2>
            <p className="text-xl">
              ফলাফল: <span className="font-bold text-blue-400">{scoreBlue}</span> -{" "}
              <span className="font-bold text-red-400">{scoreRed}</span>
            </p>
            <p className="text-lg font-semibold">{resultMsg}</p>
            <p className="text-xs text-emerald-300">মোট জয়: {wins} 🏆</p>
            <button
              onClick={restartGame}
              className="mt-2 rounded-full bg-emerald-500 px-8 py-3 text-lg font-bold text-white shadow-lg transition hover:scale-105 hover:bg-emerald-400 active:scale-95"
            >
              আবার খেলুন ↻
            </button>
          </div>
        )}
      </div>

      {status === "playing" && (
        <div className="flex w-full max-w-[900px] items-center justify-between gap-4 select-none md:hidden">
          <div className="grid grid-cols-3 grid-rows-3 gap-1">
            <div />
            <TouchBtn label="▲" onDown={() => setKey("ArrowUp", true)} onUp={() => setKey("ArrowUp", false)} />
            <div />
            <TouchBtn label="◀" onDown={() => setKey("ArrowLeft", true)} onUp={() => setKey("ArrowLeft", false)} />
            <div />
            <TouchBtn label="▶" onDown={() => setKey("ArrowRight", true)} onUp={() => setKey("ArrowRight", false)} />
            <div />
            <TouchBtn label="▼" onDown={() => setKey("ArrowDown", true)} onUp={() => setKey("ArrowDown", false)} />
            <div />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => triggerOnce("slide")}
              className="flex h-14 w-14 items-center justify-center rounded-xl bg-orange-600/90 text-xs font-bold text-white shadow active:bg-orange-400"
            >
              স্লাইড
            </button>
            <button
              onClick={() => triggerOnce("pass")}
              className="flex h-14 w-14 items-center justify-center rounded-xl bg-sky-600/90 text-xs font-bold text-white shadow active:bg-sky-400"
            >
              পাস
            </button>
            <TouchBtn label="শট" big onDown={() => setKey(" ", true)} onUp={() => setKey(" ", false)} />
          </div>
        </div>
      )}

      <p className="hidden max-w-[900px] text-center text-sm text-slate-500 md:block">
        চালনা: <b>WASD</b> / <b>তীর কী</b> &nbsp;|&nbsp; শট: <b>স্পেস</b> (চেপে ধরে ছাড়ুন) &nbsp;|&nbsp; পাস:{" "}
        <b>E</b> &nbsp;|&nbsp; স্লাইড ট্যাকল: <b>F</b>
      </p>
    </div>
  );
}

function TouchBtn({
  label,
  onDown,
  onUp,
  big,
}: {
  label: string;
  onDown: () => void;
  onUp: () => void;
  big?: boolean;
}) {
  return (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        onDown();
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        onUp();
      }}
      onPointerLeave={() => onUp()}
      onPointerCancel={() => onUp()}
      className={`flex items-center justify-center rounded-xl bg-slate-800/90 font-bold text-white shadow active:bg-emerald-600 ${
        big ? "h-16 w-16 text-sm" : "h-11 w-11 text-lg"
      }`}
      style={{ touchAction: "none" }}
    >
      {label}
    </button>
  );
}
